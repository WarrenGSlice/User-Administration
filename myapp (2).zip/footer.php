<!--Warren Peterson-03/12/2020--
----GCU--CST-126--Blog Project--
----This is my own work---------
--------------------------------
----Page Footer---------------->
<div class="footer">
			<p>MyViewers &copy; <?php echo date('Y'); ?></p>
		</div>
		<!-- // footer -->

	</div>
	<!-- // container -->
</body>
</html>