<?php
    //**************************************
    //*********Programmers Heading**********
    //*Warren Peterson - Blog Project -*****
    //*03/12/2020 - This is my own work*****
    //*GCU CST-126 ---**********************
    //*************************************/
    //**********Logout Element*************/
?>
<?php 
	session_start();
	session_unset($_SESSION['user']);
	session_destroy();
	header('location: index.php');
?>