<?php
    //**************************************
    //*********Programmers Heading**********
    //*Warren Peterson - Blog Project -*****
    //*03/12/2020 - This is my own work*****
    //*GCU CST-126 ---**********************
    //*************************************/
    //****Throws error messages************/
?>
<?php if (isset($_SESSION['message'])) : ?>
      <div class="message" >
      	<p>
          <?php 
          	echo $_SESSION['message']; 
          	unset($_SESSION['message']);
          ?>
      	</p>
      </div>
<?php endif ?>